﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDADES.SP
{
    public class Durazno : Fruta
    {
        protected int _cantPelusa;

        public String Nombre
        {
            get
            {
                return "Durazno";
            }
        }

        public override bool TieneCarojo
        {
            get
            {
                return true;
            }
        }

        public Durazno()
        {

        }

        public Durazno(string color, double peso, int pelusa) : base(color, peso)
        {
            this._cantPelusa = pelusa;
        }

        protected override string FrutaToString()
        {
            string res = "";
            res += base.FrutaToString() + "\nCantidad de Pelusa: " + this._cantPelusa.ToString();
            return res;
        }

        public override string ToString()
        {
            return this.FrutaToString();
        }
    }
}
