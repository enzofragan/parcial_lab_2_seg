﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDADES.SP
{
    public abstract class Fruta
    {
        protected string _color;
        protected double _peso;

        public abstract bool TieneCarojo { get; }

        public double Peso
        {
            get
            {
                return this._peso;
            }
            set
            {
                this._peso = value;
            }
        }

        public string Color
        {
            get
            {
                return this._color;
            }
            set
            {
                this._color = value;
            }
        }



        public Fruta()
        {

        }

        public Fruta(string color, double peso)
        {
            this.Color = color;
            this.Peso = peso;
        }

        protected virtual string FrutaToString()
        {
            string res = "";
            res += "Color: " + this._color + "\nPeso: " + this._peso.ToString();
            return res;
        }
    }
}
