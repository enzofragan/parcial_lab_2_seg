﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Xml;
using System.Xml.Serialization;
using System.Data.SqlClient;

namespace ENTIDADES.SP
{
    public delegate void PrecioExcedido(object sender);
    public class Cajon<T>:ISerializar
    {
        protected int _capacidad;
        protected List<T> _elementos;
        protected double _precioUnitario;
        public event PrecioExcedido eventoPrecio;

        public List<T> Elementos
        {
            get
            {
                return this._elementos;
            }
        }

        public double PrecioTotal
        {
            get
            {
                if ((this._precioUnitario * this._elementos.Count) > 55)
                {
                    this.eventoPrecio(this);
                }

                return this._precioUnitario * this._elementos.Count;
            }
        }

        public Cajon()
        {
            this._elementos = new List<T>();
        }

        public Cajon(int capacidad) : this()
        {
            this._capacidad = capacidad;
        }

        public Cajon(double precioUnitario, int capacidad) : this(capacidad)
        {
            this._precioUnitario = precioUnitario;
        }

        public override string ToString()
        {
            string res = "";
            res += "Capacidad: " + this._capacidad.ToString() + "\nCantidad total de elementos: " + this._elementos.Count.ToString() + "\nPrecio Total: " + this.PrecioTotal.ToString();

            foreach (T item in this._elementos)
            {
                if (item != null)
                {
                    res += "\n" + item.ToString();
                }
            }

            return res;
        }

        public static Cajon<T> operator +(Cajon<T> cajon, T item)
        {
            if (cajon._elementos.Count + 1 <= cajon._capacidad)
            {
                if (cajon.PrecioTotal <= 55)
                {
                    cajon._elementos.Add(item);
                }
                else
                {
                    cajon.eventoPrecio(cajon);
                }
            }
            else
            {
                throw new CajonLlenoException("El cajon esta lleno");

            }
            return cajon;
        }

        public bool Xml(string path)
        {
            string path2 = @"\" + path;
            bool retorno = false;
            try
            {
                XmlSerializer sr = new XmlSerializer(typeof(Cajon<T>));
                XmlTextWriter xw = new XmlTextWriter((Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + path2), Encoding.UTF8);

                sr.Serialize(xw, this);
                xw.Close();
                retorno = true;

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }


            return retorno;


        }

        public bool EliminarFruta(int id)
        {
            bool retorno = false;
            try
            {
                SqlConnection conexion = new SqlConnection(Properties.Settings.Default.conexion);
                SqlCommand comando = new SqlCommand();
                comando.CommandType = CommandType.Text;
                comando.CommandText = "DELETE FROM sp_lab_II WHERE id = " + id + ";";
                conexion.Open();
                retorno = true;
                if (conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return retorno;
        }
    }
}
