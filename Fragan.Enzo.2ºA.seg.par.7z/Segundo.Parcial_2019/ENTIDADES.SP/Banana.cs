﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDADES.SP
{
    public class Banana : Fruta
    {
        protected string _paisOrigen;

        public string Nombre
        {
            get
            {
                return "banana";
            }
        }

        public override bool TieneCarojo
        {
            get
            {
                return false;
            }
        }

        public Banana()
        {

        }

        public Banana(string color, double peso, string provi) : base(color, peso)
        {
            this._paisOrigen = provi;
        }


        protected override string FrutaToString()
        {
            string res = "";
            res += base.FrutaToString() + "\nPais de Origen: " + this._paisOrigen;
            return res;
        }

        public override string ToString()
        {
            return this.FrutaToString();
        }
    }
}
