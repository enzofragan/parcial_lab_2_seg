﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Concesionaria
    {
        private int capacidad;
        private List<Vehiculo> vehiculos;

        public double PrecioDeAutos {
            get
            {
                Single res =0;
                foreach(Auto v in this.vehiculos)
                {
                    res += (Single)v;
                }
                return (double)res;
            }
        }
        public double PrecioDeMotos {
            get
            {
                Single res = 0;
                foreach (Moto v in this.vehiculos)
                {
                    res += (Single)v;
                }
                return (double)res;
            }
        }
        public double PrecioTotal {
            get
            {
                Single res = 0;
                foreach (Auto v in this.vehiculos)
                {
                    res += (Single)v;
                }
                foreach (Moto v in this.vehiculos)
                {
                    res += (Single)v;
                }
                return (double)res;
            }
        }

        private Concesionaria()
        {
            this.vehiculos = new List<Vehiculo>();
        }

        private Concesionaria(int capacidad) : this()
        {
            this.capacidad = capacidad;
        }

        public static implicit operator Concesionaria(int capacidad)
        {
            Concesionaria aux = new Concesionaria(capacidad);
            return aux;
        }

        public static string Mostrar(Concesionaria c)
        {
            string respuesta = "";
            respuesta+="Capacidad Maxima: "+c.capacidad.ToString()+"\n";
            foreach(Vehiculo v in c.vehiculos)
            {
                respuesta += (string)v;
            }
            return respuesta;
        }

        /*private double ObtenerPrecio(EVehiculo tipoVehiculo)
        {

        }*/

        public static bool operator ==(Concesionaria c, Vehiculo v)
        {
            bool respuesta = false;
            foreach(Vehiculo v1 in c.vehiculos)
            {
                if(v is Auto)
                {
                    if((Auto)v1==(Auto)v)
                    {
                        respuesta = true;
                    }
                }
                else if(v is Moto)
                {
                    if((Moto)v1==(Moto)v)
                    {
                        respuesta = true;
                    }
                }
            }
            return respuesta;
        }

        public static bool operator !=(Concesionaria c, Vehiculo v)
        {
            return !(c == v);
        }

        /*public static Concesionaria operator +(Concesionaria c, Vehiculo v)
        {
            
        }*/
    }
}
