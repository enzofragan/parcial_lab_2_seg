﻿public enum ETipo
{
    Deportivo,Sedan,Coupe,Familiar
}