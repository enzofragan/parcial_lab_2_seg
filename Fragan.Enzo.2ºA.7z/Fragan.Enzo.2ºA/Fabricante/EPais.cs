﻿public enum EPais
{
    Italia,Francia,Alemania
}