﻿public enum ECilindrada
{
    cc50,cc125,cc250,cc500
}